# /// script
# requires-python = ">=3.11"
# dependencies = ["mirage"]
#
# [tool.uv.sources]
# mirage = { path = "../../", editable = true }
# ///
"""
Airmass Function Comparison
===========================
Comparing the approximate and true airmass functions
"""

import matplotlib.pyplot as plt
import numpy as np

import mirage as mr
import mirage.vis as mrv

theta = np.linspace(0, np.pi / 2 - 0.01, int(1e3))

plt.plot(theta, mr.relative_airmass(theta, approx=True))
plt.plot(theta, mr.relative_airmass(theta, approx=False))
plt.yscale('log')
mrv.texit(
    'Airmass Functions',
    'Zenith Angle [rad]',
    'Relative airmass',
    [r'$\sec\theta$', 'Pickering'],
)
plt.show()
